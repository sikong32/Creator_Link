--------------------------------------------------------
--  Constraints for Table FOLLOW_TBL
--------------------------------------------------------

  ALTER TABLE "CRERING"."FOLLOW_TBL" MODIFY ("MB_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "CRERING"."FOLLOW_TBL" MODIFY ("FW_MB_NUMBER" NOT NULL ENABLE);
