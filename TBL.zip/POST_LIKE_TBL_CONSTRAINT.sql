--------------------------------------------------------
--  Constraints for Table POST_LIKE_TBL
--------------------------------------------------------

  ALTER TABLE "CRERING"."POST_LIKE_TBL" MODIFY ("MB_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "CRERING"."POST_LIKE_TBL" MODIFY ("BCT_CONTENT_NUMBER" NOT NULL ENABLE);
