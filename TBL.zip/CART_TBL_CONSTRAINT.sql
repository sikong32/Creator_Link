--------------------------------------------------------
--  Constraints for Table CART_TBL
--------------------------------------------------------

  ALTER TABLE "CRERING"."CART_TBL" MODIFY ("MB_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "CRERING"."CART_TBL" MODIFY ("PD_NUMBER" NOT NULL ENABLE);
  ALTER TABLE "CRERING"."CART_TBL" MODIFY ("CT_PD_QNT" NOT NULL ENABLE);
